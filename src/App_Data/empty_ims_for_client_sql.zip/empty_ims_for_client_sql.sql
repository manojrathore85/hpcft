-- --------------------------------------------------------
-- Host:                         gtssolutions.net
-- Server version:               10.5.25-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table gims.ims_mydiary
CREATE TABLE IF NOT EXISTS `ims_mydiary` (
  `email` varchar(128) NOT NULL DEFAULT '',
  `projectid` int(10) unsigned NOT NULL DEFAULT 0,
  `issueid` int(10) unsigned NOT NULL DEFAULT 0,
  `date_of_creation` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comments` text NOT NULL,
  `extra_field` text NOT NULL,
  PRIMARY KEY (`email`,`projectid`,`issueid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table gims.ims_mydiary: 0 rows
DELETE FROM `ims_mydiary`;
/*!40000 ALTER TABLE `ims_mydiary` DISABLE KEYS */;
/*!40000 ALTER TABLE `ims_mydiary` ENABLE KEYS */;

-- Dumping structure for table gims.ims_usage
CREATE TABLE IF NOT EXISTS `ims_usage` (
  `Email` varchar(64) DEFAULT NULL,
  `U_DateTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Action` varchar(64) DEFAULT NULL,
  `SubAction` text DEFAULT NULL,
  `IdKey` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`IdKey`)
) ENGINE=MyISAM AUTO_INCREMENT=92 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table gims.ims_usage: 91 rows
DELETE FROM `ims_usage`;
/*!40000 ALTER TABLE `ims_usage` DISABLE KEYS */;
INSERT INTO `ims_usage` (`Email`, `U_DateTime`, `Action`, `SubAction`, `IdKey`) VALUES
	('sanjayz@gmail.com', '2024-10-01 11:31:26', 'login', '', 1),
	('sanjayz@gmail.com', '2024-10-01 11:31:26', '/selectproject.asp', '', 2),
	('sanjayz@gmail.com', '2024-10-01 11:33:48', '/selectproject.asp', '', 3),
	('sanjayz@gmail.com', '2024-10-01 11:33:52', '/issuenavigator.asp', 'search=alloutstanding', 4),
	('sanjayz@gmail.com', '2024-10-01 11:33:55', '/viewprojects.asp', '', 5),
	('sanjayz@gmail.com', '2024-10-01 11:33:55', '/viewprojects.asp', 'Projectid=1,', 6),
	('sanjayz@gmail.com', '2024-10-01 11:34:01', '/viewprojects.asp', 'Projectid=1,mainlink=editproject&id=1', 7),
	('sanjayz@gmail.com', '2024-10-01 11:34:01', '/viewprojects.asp', 'Projectid=1,mainlink=editproject&id=1', 8),
	('sanjayz@gmail.com', '2024-10-01 11:34:07', '/editproject_process.asp', 'Projectid=1,', 9),
	('sanjayz@gmail.com', '2024-10-01 11:34:07', '/viewprojects.asp', 'Projectid=1,', 10),
	('sanjayz@gmail.com', '2024-10-01 11:34:07', '/viewprojects.asp', 'Projectid=1,', 11),
	('sanjayz@gmail.com', '2024-10-01 11:34:21', '/createissue.asp', 'Projectid=1,', 12),
	('sanjayz@gmail.com', '2024-10-01 11:34:33', '/selectProject.asp', 'Projectid=1,', 13),
	('', '2024-10-01 11:41:21', '/selectProject.asp', '', 14),
	('sanjayz@gmail.com', '2024-10-01 11:41:33', 'login', '', 15),
	('sanjayz@gmail.com', '2024-10-01 11:41:33', '/selectproject.asp', '', 16),
	('sanjayz@gmail.com', '2024-10-01 11:41:36', '/selectproject.asp', '', 17),
	('sanjayz@gmail.com', '2024-10-01 11:41:38', '/selectproject.asp', '', 18),
	('sanjayz@gmail.com', '2024-10-01 11:41:56', '/selectproject.asp', '', 19),
	('sanjayz@gmail.com', '2024-10-01 11:42:32', '/selectproject.asp', '', 20),
	('sanjayz@gmail.com', '2024-10-01 11:43:48', '/issuenavigator.asp', 'search=alloutstanding', 21),
	('sanjayz@gmail.com', '2024-10-01 11:44:14', '/selectProject.asp', '', 22),
	('sanjayz@gmail.com', '2024-10-01 11:44:15', '/selectProject.asp', '', 23),
	('sanjayz@gmail.com', '2024-10-01 11:44:58', '/selectProject.asp', '', 24),
	('sanjayz@gmail.com', '2024-10-01 11:44:58', '/viewprojects.asp', '', 25),
	('sanjayz@gmail.com', '2024-10-01 11:44:58', '/viewprojects.asp', 'Projectid=1,', 26),
	('sanjayz@gmail.com', '2024-10-01 11:45:08', '/viewprojects.asp', 'Projectid=1,mainlink=permission', 27),
	('sanjayz@gmail.com', '2024-10-01 11:45:08', '/viewprojects.asp', 'Projectid=1,mainlink=permission', 28),
	('sanjayz@gmail.com', '2024-10-01 11:45:17', '/viewprojects.asp', 'Projectid=1,mainlink=setpermissionlist', 29),
	('sanjayz@gmail.com', '2024-10-01 11:45:17', '/viewprojects.asp', 'Projectid=1,mainlink=setpermissionlist', 30),
	('sanjayz@gmail.com', '2024-10-01 11:45:21', '/viewprojects.asp', 'Projectid=1,', 31),
	('sanjayz@gmail.com', '2024-10-01 11:45:21', '/viewprojects.asp', 'Projectid=1,', 32),
	('sanjayz@gmail.com', '2024-10-01 11:48:08', '/createissue.asp', 'Projectid=1,', 33),
	('sanjayz@gmail.com', '2024-10-01 11:48:17', '/Logout.asp', 'Projectid=1,', 34),
	('sanjayz@gmail.com', '2024-10-01 11:48:31', 'login', '', 35),
	('sanjayz@gmail.com', '2024-10-01 11:48:31', '/selectproject.asp', '', 36),
	('sanjayz@gmail.com', '2024-10-01 11:48:31', '/viewprojects.asp', '', 37),
	('sanjayz@gmail.com', '2024-10-01 11:48:31', '/viewprojects.asp', 'Projectid=1,', 38),
	('sanjayz@gmail.com', '2024-10-01 11:49:01', '/createissue.asp', 'Projectid=1,', 39),
	('sanjayz@gmail.com', '2024-10-01 11:49:40', '/selectProject.asp', 'Projectid=1,', 40),
	('sanjayz@gmail.com', '2024-10-01 11:50:21', '/selectProject.asp', 'Projectid=1,', 41),
	('sanjayz@gmail.com', '2024-10-01 11:50:23', '/selectProject.asp', 'Projectid=1,', 42),
	('sanjayz@gmail.com', '2024-10-01 11:50:32', '/selectProject.asp', 'Projectid=1,', 43),
	('sanjayz@gmail.com', '2024-10-01 11:50:32', '/viewprojects.asp', 'Projectid=1,', 44),
	('sanjayz@gmail.com', '2024-10-01 11:50:32', '/viewprojects.asp', 'Projectid=1,', 45),
	('sanjayz@gmail.com', '2024-10-01 11:52:13', '/selectProject.asp', 'Projectid=1,', 46),
	('sanjayz@gmail.com', '2024-10-01 11:52:16', '/selectProject.asp', 'Projectid=1,', 47),
	('sanjayz@gmail.com', '2024-10-01 11:53:31', '/selectProject.asp', 'Projectid=1,', 48),
	('sanjayz@gmail.com', '2024-10-01 11:53:32', '/selectProject.asp', 'Projectid=1,', 49),
	('sanjayz@gmail.com', '2024-10-01 11:53:32', '/selectProject.asp', 'Projectid=1,', 50),
	('sanjayz@gmail.com', '2024-10-01 11:53:32', '/selectProject.asp', 'Projectid=1,', 51),
	('sanjayz@gmail.com', '2024-10-01 11:53:33', '/selectProject.asp', 'Projectid=1,', 52),
	('sanjayz@gmail.com', '2024-10-01 11:56:05', '/selectProject.asp', 'Projectid=1,', 53),
	('sanjayz@gmail.com', '2024-10-01 11:56:42', '/selectProject.asp', 'Projectid=1,', 54),
	('sanjayz@gmail.com', '2024-10-01 12:00:38', '/selectProject.asp', 'Projectid=1,', 55),
	('sanjayz@gmail.com', '2024-10-01 12:01:31', '/selectProject.asp', 'Projectid=1,', 56),
	('sanjayz@gmail.com', '2024-10-01 12:01:38', '/createissue.asp', 'Projectid=1,', 57),
	('sanjayz@gmail.com', '2024-10-01 12:01:42', '/viewprojects.asp', 'Projectid=1,', 58),
	('sanjayz@gmail.com', '2024-10-01 12:01:42', '/viewprojects.asp', 'Projectid=1,', 59),
	('sanjayz@gmail.com', '2024-10-01 12:02:51', '/viewprojects.asp', 'Projectid=1,', 60),
	('sanjayz@gmail.com', '2024-10-01 12:02:51', '/viewprojects.asp', 'Projectid=1,', 61),
	('sanjayz@gmail.com', '2024-10-01 12:22:43', '/createissue.asp', 'Projectid=1,', 62),
	('sanjayz@gmail.com', '2024-10-01 12:23:23', '/createissue_process.asp', 'Projectid=1,', 63),
	('sanjayz@gmail.com', '2024-10-01 12:28:06', 'login', '', 64),
	('sanjayz@gmail.com', '2024-10-01 12:28:07', '/selectproject.asp', '', 65),
	('sanjayz@gmail.com', '2024-10-01 12:28:14', '/viewprojects.asp', '', 66),
	('sanjayz@gmail.com', '2024-10-01 12:28:14', '/viewprojects.asp', 'Projectid=1,', 67),
	('sanjayz@gmail.com', '2024-10-01 12:28:22', '/createissue.asp', 'Projectid=1,', 68),
	('sanjayz@gmail.com', '2024-10-01 12:28:33', '/createissue_process.asp', 'Projectid=1,', 69),
	('sanjayz@gmail.com', '2024-10-01 12:28:37', '/createissue_process.asp', 'Projectid=1,', 70),
	('sanjayz@gmail.com', '2024-10-01 12:31:17', '/createissue_process.asp', 'Projectid=1,', 71),
	('sanjayz@gmail.com', '2024-10-01 12:31:41', '/createissue_process.asp', 'Projectid=1,', 72),
	('sanjayz@gmail.com', '2024-10-01 12:33:17', '/createissue_process.asp', 'Projectid=1,', 73),
	('sanjayz@gmail.com', '2024-10-01 12:33:27', '/createissue_process.asp', 'Projectid=1,', 74),
	('', '2024-10-01 12:41:05', '/createissue_process.asp', '', 75),
	('sanjayz@gmail.com', '2024-10-01 12:41:12', 'login', '', 76),
	('sanjayz@gmail.com', '2024-10-01 12:41:12', '/selectproject.asp', '', 77),
	('sanjayz@gmail.com', '2024-10-01 12:41:19', '/selectproject.asp', '', 78),
	('sanjayz@gmail.com', '2024-10-01 12:41:23', '/selectproject.asp', '', 79),
	('sanjayz@gmail.com', '2024-10-01 12:41:24', '/selectproject.asp', '', 80),
	('sanjayz@gmail.com', '2024-10-01 12:41:27', '/selectproject.asp', '', 81),
	('sanjayz@gmail.com', '2024-10-01 12:41:41', '/selectproject.asp', '', 82),
	('sanjayz@gmail.com', '2024-10-01 12:45:11', '/selectproject.asp', '', 83),
	('sanjayz@gmail.com', '2024-10-01 12:45:14', '/createissue.asp', 'Projectid=1,', 84),
	('sanjayz@gmail.com', '2024-10-01 12:45:35', '/createissue_process.asp', 'Projectid=1,', 85),
	('sanjayz@gmail.com', '2024-10-01 12:45:36', '/issuenavigator.asp', 'Projectid=1,search=all', 86),
	('sanjayz@gmail.com', '2024-10-01 12:48:36', '/issuedetails.asp', 'Projectid=1,issueid=1&prjid=1', 87),
	('sanjayz@gmail.com', '2024-10-01 12:48:36', '/issuedetails.asp', 'Projectid=1,issueid=1&prjid=1', 88),
	('sanjayz@gmail.com', '2024-10-01 12:49:10', '/comment.asp', 'Projectid=1,', 89),
	('sanjayz@gmail.com', '2024-10-01 12:49:10', '/issuedetails.asp', 'Projectid=1,issueid=1&prjid=1', 90),
	('sanjayz@gmail.com', '2024-10-01 12:49:10', '/issuedetails.asp', 'Projectid=1,issueid=1&prjid=1', 91);
/*!40000 ALTER TABLE `ims_usage` ENABLE KEYS */;

-- Dumping structure for table gims.issuechangescomments
CREATE TABLE IF NOT EXISTS `issuechangescomments` (
  `ProjectId` int(10) unsigned NOT NULL DEFAULT 0,
  `IssueId` int(10) unsigned NOT NULL DEFAULT 0,
  `Field` varchar(32) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `ChangesBy` varchar(64) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `UpdateDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `NewValue` text CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `Comments` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `LastValue` text CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `Rowid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Rowid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf16 COLLATE=utf16_unicode_ci;

-- Dumping data for table gims.issuechangescomments: 1 rows
DELETE FROM `issuechangescomments`;
/*!40000 ALTER TABLE `issuechangescomments` DISABLE KEYS */;
INSERT INTO `issuechangescomments` (`ProjectId`, `IssueId`, `Field`, `ChangesBy`, `UpdateDate`, `NewValue`, `Comments`, `LastValue`, `Rowid`) VALUES
	(1, 1, '', 'sanjayz@gmail.com', '2024-10-01 12:49:10', NULL, '<p>issue link was wrong , corrected , now checking mail</p>', NULL, 1);
/*!40000 ALTER TABLE `issuechangescomments` ENABLE KEYS */;

-- Dumping structure for table gims.issues
CREATE TABLE IF NOT EXISTS `issues` (
  `Projectid` int(10) unsigned NOT NULL DEFAULT 0,
  `IssueId` int(10) unsigned NOT NULL DEFAULT 0,
  `CreateDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `UpdateDate` datetime DEFAULT '0000-00-00 00:00:00',
  `IssueType` varchar(32) NOT NULL DEFAULT '',
  `Severity` varchar(16) NOT NULL DEFAULT '',
  `Summary` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `AssignTo` varchar(64) NOT NULL DEFAULT '',
  `Reporter` varchar(64) NOT NULL DEFAULT '',
  `Description` text CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `Status` varchar(32) NOT NULL DEFAULT 'Opened',
  `AttachedFilePath` text DEFAULT NULL,
  `reportUsers` text DEFAULT NULL,
  PRIMARY KEY (`IssueId`,`Projectid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table gims.issues: 0 rows
DELETE FROM `issues`;
/*!40000 ALTER TABLE `issues` DISABLE KEYS */;
/*!40000 ALTER TABLE `issues` ENABLE KEYS */;

-- Dumping structure for table gims.permissions
CREATE TABLE IF NOT EXISTS `permissions` (
  `PermissionId` varchar(64) NOT NULL DEFAULT '',
  `PRead` char(1) DEFAULT NULL,
  `PWrite` char(1) DEFAULT NULL,
  `PAdd` char(1) DEFAULT NULL,
  `PDelete` char(1) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  PRIMARY KEY (`PermissionId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table gims.permissions: 5 rows
DELETE FROM `permissions`;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` (`PermissionId`, `PRead`, `PWrite`, `PAdd`, `PDelete`, `Description`) VALUES
	('project_demo', 'T', 'F', 'F', 'F', 'read only'),
	('project_user', 'T', 'T', 'T', 'F', 'read, write and add'),
	('project_mgnt', 'T', 'T', 'T', 'T', 'read, write, add and delete '),
	('project_dev', 'T', 'T', 'F', 'F', 'read and write'),
	('all', 'T', 'T', 'T', 'T', 'read,write,add,delete plus administrative privledges');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;

-- Dumping structure for table gims.projects
CREATE TABLE IF NOT EXISTS `projects` (
  `ProjectId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ProjectName` varchar(128) NOT NULL DEFAULT '',
  `LeadDeveloper` varchar(64) NOT NULL DEFAULT '',
  `Description` text DEFAULT NULL,
  `DesignDocPath` text DEFAULT NULL,
  `CreateDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ProjectWatchList` text DEFAULT NULL,
  PRIMARY KEY (`ProjectId`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table gims.projects: 1 rows
DELETE FROM `projects`;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` (`ProjectId`, `ProjectName`, `LeadDeveloper`, `Description`, `DesignDocPath`, `CreateDate`, `ProjectWatchList`) VALUES
	(1, 'IMS', 'sanjayz@gmail.com', 'asdfsadf', 'Sample.jpg', '2005-03-31 00:00:00', 'sanjayz@gmail.com,agrawalatul@gmail.com');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;

-- Dumping structure for table gims.reminder_table
CREATE TABLE IF NOT EXISTS `reminder_table` (
  `rem_idCol` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `issueidCol` int(10) unsigned NOT NULL DEFAULT 0,
  `TypeCol` varchar(32) NOT NULL DEFAULT '',
  `Due_DateTimeCol` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `TimeZoneCol` char(3) NOT NULL DEFAULT '',
  `Date_enteredCol` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Person_ResponsibleCol` varchar(64) NOT NULL DEFAULT '',
  `AlertFrequencyCol` varchar(16) NOT NULL DEFAULT '',
  `StateCol` varchar(16) NOT NULL DEFAULT '',
  `NotesCol` text NOT NULL,
  `DescCol` text NOT NULL,
  `DaysOfWeekCol` varchar(40) NOT NULL DEFAULT '',
  `MonthsOfYearCol` varchar(60) NOT NULL DEFAULT '',
  PRIMARY KEY (`rem_idCol`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table gims.reminder_table: 0 rows
DELETE FROM `reminder_table`;
/*!40000 ALTER TABLE `reminder_table` DISABLE KEYS */;
/*!40000 ALTER TABLE `reminder_table` ENABLE KEYS */;

-- Dumping structure for table gims.userprofile
CREATE TABLE IF NOT EXISTS `userprofile` (
  `Email` varchar(64) NOT NULL DEFAULT '',
  `Password` varchar(16) NOT NULL DEFAULT '',
  `FirstName` varchar(64) NOT NULL DEFAULT '',
  `LastName` varchar(64) NOT NULL DEFAULT '',
  `Address` varchar(255) DEFAULT NULL,
  `Mobile` varchar(16) DEFAULT NULL,
  `HPhone` varchar(16) DEFAULT NULL,
  `OPhone` varchar(16) DEFAULT NULL,
  `YahooId` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`Email`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table gims.userprofile: 1 rows
DELETE FROM `userprofile`;
/*!40000 ALTER TABLE `userprofile` DISABLE KEYS */;
INSERT INTO `userprofile` (`Email`, `Password`, `FirstName`, `LastName`, `Address`, `Mobile`, `HPhone`, `OPhone`, `YahooId`) VALUES
	('sanjayz@gmail.com', 'ims123', 'Sanjay', 'Agrawal', 'New Jersey', '7327544393', '7327544394', '7327544394', 'sanjay_mailcity_com');
/*!40000 ALTER TABLE `userprofile` ENABLE KEYS */;

-- Dumping structure for table gims.users
CREATE TABLE IF NOT EXISTS `users` (
  `Email` varchar(64) NOT NULL DEFAULT '',
  `ProjectId` int(10) unsigned NOT NULL DEFAULT 0,
  `PermissionId` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`Email`,`ProjectId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table gims.users: 1 rows
DELETE FROM `users`;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`Email`, `ProjectId`, `PermissionId`) VALUES
	('sanjayz@gmail.com', 1, 'all');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
