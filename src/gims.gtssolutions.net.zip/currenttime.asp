<%

response.Write(now)
%>