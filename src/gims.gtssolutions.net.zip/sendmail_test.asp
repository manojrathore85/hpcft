<%
 Set myMail=CreateObject("CDO.Message")
        'Name or IP of remote SMTP server
        myMail.Configuration.Fields.Item("http://schemas.microsoft.com/cdo/configuration/smtpserver") = "relay-hosting.secureserver.net"
        'Server port
        myMail.Configuration.Fields.Item("http://schemas.microsoft.com/cdo/configuration/smtpserverport") = 25
        myMail.Configuration.Fields.Item("http://schemas.microsoft.com/cdo/configuration/sendusing")= 2
        myMail.Configuration.Fields.Item("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate") = "1" 'Use 0 for anonymous
        myMail.Configuration.Fields.Item("http://schemas.microsoft.com/cdo/configuration/sendusername") = "ims@gtsims.com"
        myMail.Configuration.Fields.Item("http://schemas.microsoft.com/cdo/configuration/sendpassword") = "ims123"
        myMail.Configuration.Fields.Item("http://schemas.microsoft.com/cdo/configuration/smtpusessl") = "false"
        myMail.Configuration.Fields.Update
		if err.number <> 0 then
			response.write "Error number -" & err.number & "| Error Desc -" & err.description & "| Error Line -" & err.line
			err.clear
		end if
        myMail.Subject = "Test Mail"
        myMail.From = "Atul<imsadmin@gtsims.com>"
		myMail.To = "agrawalatul@gmail.com"
		myMail.ReplyTo ="agrawalatul@gmail.com;imsadmin@gtsims.com"
        myMail.TextBody = "test mail body"
  		
		on error resume next
		myMail.Send
		if err.number <> 0 then
			response.write "Error number " & err.number & " Error Desc " & err.description
			err.clear
			response.End()
		end if

        set myMail=nothing
%>